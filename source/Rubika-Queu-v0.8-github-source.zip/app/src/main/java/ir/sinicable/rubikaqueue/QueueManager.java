package ir.sinicable.rubikaqueue;
import android.content.*;
public class QueueManager {
 private final QueueDatabase db;
 public QueueManager(Context c){db=new QueueDatabase(c);}
 public QueueDatabase database(){return db;}
}
